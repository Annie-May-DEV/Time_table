<?php
require_once 'includes/config.php';

echo "<h2>Database Connection Check</h2>";

try {
    // Test connection
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    echo "<p style='color: green;'>✓ Database connection successful</p>";
    
    // Check if teachers table exists and has data
    $stmt = $pdo->query("SELECT COUNT(*) as count FROM teachers");
    $result = $stmt->fetch(PDO::FETCH_ASSOC);
    echo "<p>✓ Teachers table exists with " . $result['count'] . " records</p>";
    
    // Check if users table exists and has data
    $stmt = $pdo->query("SELECT COUNT(*) as count FROM users");
    $result = $stmt->fetch(PDO::FETCH_ASSOC);
    echo "<p>✓ Users table exists with " . $result['count'] . " records</p>";
    
    // Test getTeachers function
    function testGetTeachers() {
        global $pdo;
        $stmt = $pdo->query("
            SELECT t.*, u.username, u.email, u.full_name 
            FROM teachers t 
            JOIN users u ON t.user_id = u.id 
            ORDER BY u.full_name
        ");
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
    
    $teachers = testGetTeachers();
    echo "<p>✓ getTeachers function works - found " . count($teachers) . " teachers</p>";
    
    echo "<h3>All Systems Working!</h3>";
    
} catch (PDOException $e) {
    echo "<p style='color: red;'>✗ Database error: " . $e->getMessage() . "</p>";
}
?>

<a href="admin/manage_teachers.php">Go to Manage Teachers</a>
-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 15, 2025 at 03:45 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `timetable_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `classes`
--

CREATE TABLE `classes` (
  `id` int(11) NOT NULL,
  `class_name` varchar(50) NOT NULL,
  `class_level` varchar(20) DEFAULT NULL,
  `capacity` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `classes`
--

INSERT INTO `classes` (`id`, `class_name`, `class_level`, `capacity`, `created_at`) VALUES
(1, 'Grade 10A', 'Grade 10', 40, '2025-11-15 14:27:00'),
(2, 'Grade 10B', 'Grade 10', 35, '2025-11-15 14:27:00'),
(3, 'Grade 11A', 'Grade 11', 38, '2025-11-15 14:27:00'),
(4, 'Grade 11B', 'Grade 11', 42, '2025-11-15 14:27:00'),
(5, 'Grade 12A', 'Grade 12', 36, '2025-11-15 14:27:00'),
(6, 'Grade 12B', 'Grade 12', 39, '2025-11-15 14:27:00');

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `token` varchar(255) NOT NULL,
  `expires_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `periods`
--

CREATE TABLE `periods` (
  `id` int(11) NOT NULL,
  `period_name` varchar(50) NOT NULL,
  `start_time` time NOT NULL,
  `end_time` time NOT NULL,
  `day_of_week` enum('Monday','Tuesday','Wednesday','Thursday','Friday','Saturday') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `periods`
--

INSERT INTO `periods` (`id`, `period_name`, `start_time`, `end_time`, `day_of_week`) VALUES
(1, 'Period 1', '08:00:00', '08:40:00', 'Monday'),
(2, 'Period 2', '08:40:00', '09:20:00', 'Monday'),
(3, 'Period 3', '09:20:00', '10:00:00', 'Monday'),
(4, 'Break', '10:00:00', '10:20:00', 'Monday'),
(5, 'Period 4', '10:20:00', '11:00:00', 'Monday'),
(6, 'Period 5', '11:00:00', '11:40:00', 'Monday'),
(7, 'Period 6', '11:40:00', '12:20:00', 'Monday'),
(8, 'Lunch', '12:20:00', '13:00:00', 'Monday'),
(9, 'Period 7', '13:00:00', '13:40:00', 'Monday'),
(10, 'Period 8', '13:40:00', '14:20:00', 'Monday'),
(11, 'Period 1', '08:00:00', '08:40:00', 'Tuesday'),
(12, 'Period 2', '08:40:00', '09:20:00', 'Tuesday'),
(13, 'Period 3', '09:20:00', '10:00:00', 'Tuesday'),
(14, 'Break', '10:00:00', '10:20:00', 'Tuesday'),
(15, 'Period 4', '10:20:00', '11:00:00', 'Tuesday'),
(16, 'Period 5', '11:00:00', '11:40:00', 'Tuesday'),
(17, 'Period 6', '11:40:00', '12:20:00', 'Tuesday'),
(18, 'Lunch', '12:20:00', '13:00:00', 'Tuesday'),
(19, 'Period 7', '13:00:00', '13:40:00', 'Tuesday'),
(20, 'Period 8', '13:40:00', '14:20:00', 'Tuesday'),
(21, 'Period 1', '08:00:00', '08:40:00', 'Wednesday'),
(22, 'Period 2', '08:40:00', '09:20:00', 'Wednesday'),
(23, 'Period 3', '09:20:00', '10:00:00', 'Wednesday'),
(24, 'Break', '10:00:00', '10:20:00', 'Wednesday'),
(25, 'Period 4', '10:20:00', '11:00:00', 'Wednesday'),
(26, 'Period 5', '11:00:00', '11:40:00', 'Wednesday'),
(27, 'Period 6', '11:40:00', '12:20:00', 'Wednesday'),
(28, 'Lunch', '12:20:00', '13:00:00', 'Wednesday'),
(29, 'Period 7', '13:00:00', '13:40:00', 'Wednesday'),
(30, 'Period 8', '13:40:00', '14:20:00', 'Wednesday'),
(31, 'Period 1', '08:00:00', '08:40:00', 'Thursday'),
(32, 'Period 2', '08:40:00', '09:20:00', 'Thursday'),
(33, 'Period 3', '09:20:00', '10:00:00', 'Thursday'),
(34, 'Break', '10:00:00', '10:20:00', 'Thursday'),
(35, 'Period 4', '10:20:00', '11:00:00', 'Thursday'),
(36, 'Period 5', '11:00:00', '11:40:00', 'Thursday'),
(37, 'Period 6', '11:40:00', '12:20:00', 'Thursday'),
(38, 'Lunch', '12:20:00', '13:00:00', 'Thursday'),
(39, 'Period 7', '13:00:00', '13:40:00', 'Thursday'),
(40, 'Period 8', '13:40:00', '14:20:00', 'Thursday'),
(41, 'Period 1', '08:00:00', '08:40:00', 'Friday'),
(42, 'Period 2', '08:40:00', '09:20:00', 'Friday'),
(43, 'Period 3', '09:20:00', '10:00:00', 'Friday'),
(44, 'Break', '10:00:00', '10:20:00', 'Friday'),
(45, 'Period 4', '10:20:00', '11:00:00', 'Friday'),
(46, 'Period 5', '11:00:00', '11:40:00', 'Friday'),
(47, 'Period 6', '11:40:00', '12:20:00', 'Friday'),
(48, 'Lunch', '12:20:00', '13:00:00', 'Friday'),
(49, 'Period 7', '13:00:00', '13:40:00', 'Friday'),
(50, 'Period 8', '13:40:00', '14:20:00', 'Friday');

-- --------------------------------------------------------

--
-- Table structure for table `rooms`
--

CREATE TABLE `rooms` (
  `id` int(11) NOT NULL,
  `room_number` varchar(20) NOT NULL,
  `room_type` varchar(50) DEFAULT NULL,
  `capacity` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `rooms`
--

INSERT INTO `rooms` (`id`, `room_number`, `room_type`, `capacity`, `created_at`) VALUES
(1, 'R101', 'Classroom', 45, '2025-11-15 14:27:00'),
(2, 'R102', 'Classroom', 40, '2025-11-15 14:27:00'),
(3, 'R103', 'Classroom', 35, '2025-11-15 14:27:00'),
(4, 'LAB1', 'Laboratory', 30, '2025-11-15 14:27:00'),
(5, 'COMP1', 'Computer Lab', 25, '2025-11-15 14:27:00'),
(6, 'LIB', 'Library', 50, '2025-11-15 14:27:00');

-- --------------------------------------------------------

--
-- Table structure for table `students`
--

CREATE TABLE `students` (
  `id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `student_id` varchar(20) NOT NULL,
  `class_id` int(11) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `parent_phone` varchar(20) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `students`
--

INSERT INTO `students` (`id`, `user_id`, `student_id`, `class_id`, `phone`, `parent_phone`, `created_at`) VALUES
(1, 6, 'S2023001', 1, '+260955111111', '+260955111112', '2025-11-15 14:27:01'),
(2, 7, 'S2023002', 1, '+260955111113', '+260955111114', '2025-11-15 14:27:01'),
(3, 8, 'S2023003', 2, '+260955111115', '+260955111116', '2025-11-15 14:27:01');

-- --------------------------------------------------------

--
-- Table structure for table `subjects`
--

CREATE TABLE `subjects` (
  `id` int(11) NOT NULL,
  `subject_code` varchar(20) NOT NULL,
  `subject_name` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `subjects`
--

INSERT INTO `subjects` (`id`, `subject_code`, `subject_name`, `description`, `created_at`) VALUES
(1, 'MATH', 'Mathematics', 'Core mathematics curriculum', '2025-11-15 14:27:00'),
(2, 'ENG', 'English Language', 'English language and literature', '2025-11-15 14:27:00'),
(3, 'SCI', 'Science', 'General science', '2025-11-15 14:27:00'),
(4, 'BIO', 'Biology', 'Biological sciences', '2025-11-15 14:27:00'),
(5, 'CHEM', 'Chemistry', 'Chemical sciences', '2025-11-15 14:27:00'),
(6, 'PHY', 'Physics', 'Physical sciences', '2025-11-15 14:27:00'),
(7, 'HIST', 'History', 'World and local history', '2025-11-15 14:27:00'),
(8, 'GEO', 'Geography', 'Physical and human geography', '2025-11-15 14:27:00'),
(9, 'COMP', 'Computer Studies', 'Computer science and IT', '2025-11-15 14:27:00'),
(10, 'BUS', 'Business Studies', 'Business and commerce', '2025-11-15 14:27:00');

-- --------------------------------------------------------

--
-- Table structure for table `teachers`
--

CREATE TABLE `teachers` (
  `id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `teacher_code` varchar(20) NOT NULL,
  `specialization` varchar(100) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `teachers`
--

INSERT INTO `teachers` (`id`, `user_id`, `teacher_code`, `specialization`, `phone`) VALUES
(1, 2, 'T001', 'Mathematics and Physics', '+260955123456'),
(2, 3, 'T002', 'English Literature', '+260955123457'),
(3, 4, 'T003', 'Science and Biology', '+260955123458'),
(4, 5, 'T004', 'Computer Studies', '+260955123459'),
(5, 9, 'this', 'this', '0950851601');

-- --------------------------------------------------------

--
-- Table structure for table `timetable_entries`
--

CREATE TABLE `timetable_entries` (
  `id` int(11) NOT NULL,
  `period_id` int(11) DEFAULT NULL,
  `subject_id` int(11) DEFAULT NULL,
  `teacher_id` int(11) DEFAULT NULL,
  `class_id` int(11) DEFAULT NULL,
  `room_id` int(11) DEFAULT NULL,
  `day_of_week` enum('Monday','Tuesday','Wednesday','Thursday','Friday','Saturday') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `timetable_entries`
--

INSERT INTO `timetable_entries` (`id`, `period_id`, `subject_id`, `teacher_id`, `class_id`, `room_id`, `day_of_week`) VALUES
(1, 1, 1, 1, 1, 1, 'Monday'),
(2, 2, 2, 2, 1, 1, 'Monday'),
(3, 3, 3, 3, 1, 1, 'Monday'),
(4, 5, 4, 3, 1, 4, 'Monday'),
(5, 6, 9, 4, 1, 5, 'Monday'),
(6, 11, 1, 1, 1, 1, 'Tuesday'),
(7, 12, 2, 2, 1, 1, 'Tuesday'),
(8, 13, 5, 3, 1, 4, 'Tuesday'),
(9, 21, 1, 1, 1, 1, 'Wednesday'),
(10, 22, 6, 1, 1, 1, 'Wednesday'),
(11, 23, 2, 2, 1, 1, 'Wednesday'),
(12, 10, 9, 5, 6, 6, 'Friday');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `email` varchar(100) DEFAULT NULL,
  `role` enum('admin','teacher','student') DEFAULT 'student',
  `full_name` varchar(100) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `last_login` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `email`, `role`, `full_name`, `created_at`, `updated_at`, `last_login`) VALUES
(1, 'admin', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'admin@kabulonga.edu.zm', 'admin', 'System Administrator', '2025-11-15 14:27:00', '2025-11-15 14:27:00', NULL),
(2, 'teacher1', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'teacher1@kabulonga.edu.zm', 'teacher', 'Mr. John Banda', '2025-11-15 14:27:00', '2025-11-15 14:27:00', NULL),
(3, 'teacher2', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'teacher2@kabulonga.edu.zm', 'teacher', 'Mrs. Sarah Mwansa', '2025-11-15 14:27:00', '2025-11-15 14:27:00', NULL),
(4, 'teacher3', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'teacher3@kabulonga.edu.zm', 'teacher', 'Mr. David Phiri', '2025-11-15 14:27:00', '2025-11-15 14:27:00', NULL),
(5, 'teacher4', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'teacher4@kabulonga.edu.zm', 'teacher', 'Ms. Grace Tembo', '2025-11-15 14:27:00', '2025-11-15 14:27:00', NULL),
(6, 'student1', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'student1@kabulonga.edu.zm', 'student', 'Chanda Musonda', '2025-11-15 14:27:01', '2025-11-15 14:27:01', NULL),
(7, 'student2', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'student2@kabulonga.edu.zm', 'student', 'Bwalya Mwape', '2025-11-15 14:27:01', '2025-11-15 14:27:01', NULL),
(8, 'student3', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'student3@kabulonga.edu.zm', 'student', 'Mwila Phiri', '2025-11-15 14:27:01', '2025-11-15 14:27:01', NULL),
(9, 'this this', '$2y$10$CsdgWh.B6QhUnqI.aFl/Vucs9TBrwMr5M7bom7Bgk0ZE2Df2gR1Me', 'this@gmail.com', 'teacher', 'this', '2025-11-15 14:31:21', '2025-11-15 14:31:21', NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `classes`
--
ALTER TABLE `classes`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `periods`
--
ALTER TABLE `periods`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `rooms`
--
ALTER TABLE `rooms`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `room_number` (`room_number`);

--
-- Indexes for table `students`
--
ALTER TABLE `students`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `student_id` (`student_id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `class_id` (`class_id`);

--
-- Indexes for table `subjects`
--
ALTER TABLE `subjects`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `subject_code` (`subject_code`);

--
-- Indexes for table `teachers`
--
ALTER TABLE `teachers`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `teacher_code` (`teacher_code`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `timetable_entries`
--
ALTER TABLE `timetable_entries`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unique_schedule` (`period_id`,`day_of_week`,`teacher_id`),
  ADD UNIQUE KEY `unique_room_schedule` (`period_id`,`day_of_week`,`room_id`),
  ADD UNIQUE KEY `unique_class_schedule` (`period_id`,`day_of_week`,`class_id`),
  ADD KEY `subject_id` (`subject_id`),
  ADD KEY `teacher_id` (`teacher_id`),
  ADD KEY `class_id` (`class_id`),
  ADD KEY `room_id` (`room_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `classes`
--
ALTER TABLE `classes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `password_resets`
--
ALTER TABLE `password_resets`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `periods`
--
ALTER TABLE `periods`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=51;

--
-- AUTO_INCREMENT for table `rooms`
--
ALTER TABLE `rooms`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `students`
--
ALTER TABLE `students`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `subjects`
--
ALTER TABLE `subjects`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `teachers`
--
ALTER TABLE `teachers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `timetable_entries`
--
ALTER TABLE `timetable_entries`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD CONSTRAINT `password_resets_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `students`
--
ALTER TABLE `students`
  ADD CONSTRAINT `students_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `students_ibfk_2` FOREIGN KEY (`class_id`) REFERENCES `classes` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `teachers`
--
ALTER TABLE `teachers`
  ADD CONSTRAINT `teachers_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `timetable_entries`
--
ALTER TABLE `timetable_entries`
  ADD CONSTRAINT `timetable_entries_ibfk_1` FOREIGN KEY (`period_id`) REFERENCES `periods` (`id`),
  ADD CONSTRAINT `timetable_entries_ibfk_2` FOREIGN KEY (`subject_id`) REFERENCES `subjects` (`id`),
  ADD CONSTRAINT `timetable_entries_ibfk_3` FOREIGN KEY (`teacher_id`) REFERENCES `teachers` (`id`),
  ADD CONSTRAINT `timetable_entries_ibfk_4` FOREIGN KEY (`class_id`) REFERENCES `classes` (`id`),
  ADD CONSTRAINT `timetable_entries_ibfk_5` FOREIGN KEY (`room_id`) REFERENCES `rooms` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

// Enhanced functionality for the timetable system
document.addEventListener('DOMContentLoaded', function() {
    // Auto-refresh timetable every 30 seconds
    setInterval(function() {
        if (window.location.pathname.includes('view_timetable') || 
            window.location.pathname.includes('generate_timetable')) {
            window.location.reload();
        }
    }, 30000);

    // Conflict detection warning
    const forms = document.querySelectorAll('form');
    forms.forEach(form => {
        form.addEventListener('submit', function(e) {
            const submitBtn = this.querySelector('[type="submit"]');
            if (submitBtn && submitBtn.name === 'add_schedule') {
                if (!confirm('Are you sure you want to add this schedule entry?')) {
                    e.preventDefault();
                }
            }
        });
    });

    // Print timetable functionality
    const printButtons = document.querySelectorAll('.print-timetable');
    printButtons.forEach(btn => {
        btn.addEventListener('click', function() {
            window.print();
        });
    });

    // Real-time form validation
    const inputs = document.querySelectorAll('input[required], select[required]');
    inputs.forEach(input => {
        input.addEventListener('blur', function() {
            if (!this.value) {
                this.classList.add('is-invalid');
            } else {
                this.classList.remove('is-invalid');
            }
        });
    });
});

// AJAX function to check availability (for future enhancement)
function checkAvailability(periodId, teacherId, roomId, classId, day) {
    // This would be implemented with actual AJAX calls in a future version
    console.log('Checking availability...');
    return true;
}
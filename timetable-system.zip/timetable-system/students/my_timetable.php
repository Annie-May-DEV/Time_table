<?php
require_once '../includes/config.php';
require_once '../includes/auth.php';
require_once '../includes/functions.php';
redirectIfNotLoggedIn();
redirectIfNotStudent();

// Get student information
$student_id = null;
$class_id = null;
$stmt = $pdo->prepare("SELECT s.*, c.class_name FROM students s JOIN classes c ON s.class_id = c.id WHERE s.user_id = ?");
$stmt->execute([$_SESSION['user_id']]);
$student = $stmt->fetch(PDO::FETCH_ASSOC);

if ($student) {
    $student_id = $student['id'];
    $class_id = $student['class_id'];
    $class_name = $student['class_name'];
}

$days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday'];
$selected_day = isset($_GET['day']) ? $_GET['day'] : 'Monday';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Timetable - Student Portal</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link href="../assets/css/style.css" rel="stylesheet">
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-success">
        <div class="container">
            <a class="navbar-brand" href="../index.php">
                <i class="fas fa-user-graduate"></i> Kabulonga SS - Student Portal
            </a>
            <div class="navbar-nav ms-auto">
                <a class="nav-link" href="dashboard.php"><i class="fas fa-tachometer-alt"></i> Dashboard</a>
                <a class="nav-link" href="profile.php"><i class="fas fa-user"></i> Profile</a>
                <a class="nav-link" href="../logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a>
            </div>
        </div>
    </nav>
    
    <div class="container mt-4">
        <div class="card">
            <div class="card-header bg-primary text-white">
                <h4><i class="fas fa-calendar-week"></i> My Class Timetable</h4>
                <p class="mb-0">Class: <?php echo $class_name; ?> | Student: <?php echo $_SESSION['full_name']; ?></p>
            </div>
            <div class="card-body">
                <?php if (!$student): ?>
                    <div class="alert alert-warning">
                        Student profile not found. Please contact administrator.
                    </div>
                <?php else: ?>
                    <!-- Day Selector -->
                    <div class="row mb-4">
                        <div class="col-md-8">
                            <div class="btn-group" role="group">
                                <?php foreach ($days as $day): ?>
                                    <a href="?day=<?php echo $day; ?>" 
                                       class="btn btn-<?php echo $selected_day == $day ? 'primary' : 'outline-primary'; ?>">
                                        <?php echo $day; ?>
                                    </a>
                                <?php endforeach; ?>
                            </div>
                        </div>
                        <div class="col-md-4 text-end">
                            <button class="btn btn-success print-timetable">
                                <i class="fas fa-print"></i> Print Timetable
                            </button>
                        </div>
                    </div>

                    <!-- Timetable -->
                    <div class="table-responsive">
                        <table class="table table-bordered table-hover">
                            <thead class="table-dark">
                                <tr>
                                    <th>Period</th>
                                    <th>Time</th>
                                    <th>Subject</th>
                                    <th>Teacher</th>
                                    <th>Room</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $periods = getPeriods($selected_day);
                                foreach ($periods as $period): 
                                    if (!in_array($period['period_name'], ['Break', 'Lunch'])):
                                        
                                        $stmt = $pdo->prepare("
                                            SELECT te.*, s.subject_name, u.full_name as teacher_name, r.room_number
                                            FROM timetable_entries te
                                            JOIN subjects s ON te.subject_id = s.id
                                            JOIN teachers t ON te.teacher_id = t.id
                                            JOIN users u ON t.user_id = u.id
                                            JOIN rooms r ON te.room_id = r.id
                                            WHERE te.period_id = ? AND te.day_of_week = ? AND te.class_id = ?
                                        ");
                                        $stmt->execute([$period['id'], $selected_day, $class_id]);
                                        $schedule = $stmt->fetch(PDO::FETCH_ASSOC);
                                        
                                        if ($schedule):
                                ?>
                                            <tr>
                                                <td><strong><?php echo $period['period_name']; ?></strong></td>
                                                <td><?php echo substr($period['start_time'], 0, 5) . ' - ' . substr($period['end_time'], 0, 5); ?></td>
                                                <td><?php echo $schedule['subject_name']; ?></td>
                                                <td><?php echo $schedule['teacher_name']; ?></td>
                                                <td><?php echo $schedule['room_number']; ?></td>
                                            </tr>
                                <?php 
                                        else:
                                ?>
                                            <tr>
                                                <td><strong><?php echo $period['period_name']; ?></strong></td>
                                                <td><?php echo substr($period['start_time'], 0, 5) . ' - ' . substr($period['end_time'], 0, 5); ?></td>
                                                <td colspan="3" class="text-muted text-center">No class scheduled</td>
                                            </tr>
                                <?php 
                                        endif;
                                    endif;
                                endforeach; 
                                ?>
                            </tbody>
                        </table>
                    </div>

                    <!-- Weekly Overview -->
                    <div class="mt-4">
                        <h5>Weekly Class Summary</h5>
                        <div class="row">
                            <?php foreach ($days as $day): ?>
                                <div class="col-md-2 mb-3">
                                    <div class="card">
                                        <div class="card-body text-center">
                                            <h6><?php echo substr($day, 0, 3); ?></h6>
                                            <?php
                                            $stmt = $pdo->prepare("
                                                SELECT COUNT(*) as count 
                                                FROM timetable_entries 
                                                WHERE day_of_week = ? AND class_id = ?
                                            ");
                                            $stmt->execute([$day, $class_id]);
                                            $count = $stmt->fetch(PDO::FETCH_ASSOC)['count'];
                                            ?>
                                            <h3 class="text-<?php echo $count > 0 ? 'success' : 'secondary'; ?>">
                                                <?php echo $count; ?>
                                            </h3>
                                            <small>classes</small>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <footer class="bg-dark text-white mt-5 py-3">
        <div class="container text-center">
            <p class="mb-0">&copy; 2025 Kabulonga Secondary School. Student Portal</p>
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="../assets/js/script.js"></script>
</body>
</html>
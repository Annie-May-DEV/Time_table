<?php
// Redirect to landing page
header("Location: landing.php");
exit();
?>
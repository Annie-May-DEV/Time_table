# Kabulonga Secondary School Timetable Management System

## System Requirements
- XAMPP (Apache, MySQL, PHP)
- PHP 7.4 or higher
- MySQL 5.7 or higher
- Web browser

## Installation Steps

1. **Setup XAMPP**
   - Download and install XAMPP from https://www.apachefriends.org/
   - Start Apache and MySQL services

2. **Deploy the System**
   - Place all project files in `htdocs/timetable-system/` directory
   - Create database by importing `database/timetable_db.sql` in phpMyAdmin

3. **Database Configuration**
   - Open `includes/config.php`
   - Update database credentials if different from default

4. **Access the System**
   - Open browser and go to `http://localhost/timetable-system`
   - Login with default admin credentials:
     - Username: `admin`
     - Password: `password`

## Features

### Admin Features:
- Manage teachers, subjects, classes, and rooms
- Generate conflict-free timetables
- View complete school schedule
- Real-time schedule updates

### Teacher Features:
- View personal teaching schedule
- Access class and room information

## Default Data
The system comes with:
- Admin user account
- Sample school periods (Monday-Friday)
- Basic timetable structure

## Support
For technical support, contact the system administrator at Kabulonga Secondary School.


Default Login:
Admin: username admin, password password

Teachers: Can be created through the admin panel
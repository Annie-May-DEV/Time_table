<?php
require_once 'config.php';

function getTeachers() {
    global $pdo;
    $stmt = $pdo->query("
        SELECT t.*, u.username, u.email, u.full_name 
        FROM teachers t 
        JOIN users u ON t.user_id = u.id 
        ORDER BY u.full_name
    ");
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

function getSubjects() {
    global $pdo;
    $stmt = $pdo->query("SELECT * FROM subjects ORDER BY subject_name");
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

function getClasses() {
    global $pdo;
    $stmt = $pdo->query("SELECT * FROM classes ORDER BY class_level, class_name");
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

function getRooms() {
    global $pdo;
    $stmt = $pdo->query("SELECT * FROM rooms ORDER BY room_number");
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

function getPeriods($day = 'Monday') {
    global $pdo;
    $stmt = $pdo->prepare("SELECT * FROM periods WHERE day_of_week = ? ORDER BY start_time");
    $stmt->execute([$day]);
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

function checkScheduleConflict($period_id, $teacher_id, $room_id, $class_id, $day, $exclude_id = null) {
    global $pdo;
    
    $sql = "SELECT COUNT(*) as count FROM timetable_entries 
            WHERE period_id = ? AND day_of_week = ? 
            AND (teacher_id = ? OR room_id = ? OR class_id = ?)";
    
    $params = [$period_id, $day, $teacher_id, $room_id, $class_id];
    
    if ($exclude_id) {
        $sql .= " AND id != ?";
        $params[] = $exclude_id;
    }
    
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $result = $stmt->fetch(PDO::FETCH_ASSOC);
    
    return $result['count'] > 0;
}

function getTeacherByUsername($username) {
    global $pdo;
    $stmt = $pdo->prepare("
        SELECT u.*, t.teacher_code, t.specialization, t.phone 
        FROM users u 
        JOIN teachers t ON u.id = t.user_id 
        WHERE u.username = ? AND u.role = 'teacher'
    ");
    $stmt->execute([$username]);
    return $stmt->fetch(PDO::FETCH_ASSOC);
}

function updateLastLogin($user_id) {
    global $pdo;
    $stmt = $pdo->prepare("UPDATE users SET last_login = NOW() WHERE id = ?");
    $stmt->execute([$user_id]);
}

function isUsernameTaken($username, $exclude_user_id = null) {
    global $pdo;
    $sql = "SELECT COUNT(*) as count FROM users WHERE username = ?";
    $params = [$username];
    
    if ($exclude_user_id) {
        $sql .= " AND id != ?";
        $params[] = $exclude_user_id;
    }
    
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $result = $stmt->fetch(PDO::FETCH_ASSOC);
    
    return $result['count'] > 0;
}

function getTimetableEntries($day = 'Monday', $class_id = null, $teacher_id = null) {
    global $pdo;
    
    $sql = "
        SELECT te.*, p.period_name, p.start_time, p.end_time, 
               s.subject_name, u.full_name as teacher_name, 
               c.class_name, r.room_number
        FROM timetable_entries te
        JOIN periods p ON te.period_id = p.id
        JOIN subjects s ON te.subject_id = s.id
        JOIN teachers t ON te.teacher_id = t.id
        JOIN users u ON t.user_id = u.id
        JOIN classes c ON te.class_id = c.id
        JOIN rooms r ON te.room_id = r.id
        WHERE te.day_of_week = ?
    ";
    
    $params = [$day];
    
    if ($class_id) {
        $sql .= " AND te.class_id = ?";
        $params[] = $class_id;
    }
    
    if ($teacher_id) {
        $sql .= " AND te.teacher_id = ?";
        $params[] = $teacher_id;
    }
    
    $sql .= " ORDER BY p.start_time, c.class_name";
    
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

function getTeacherSchedule($teacher_id, $day = null) {
    global $pdo;
    
    $sql = "
        SELECT te.*, p.period_name, p.start_time, p.end_time,
               s.subject_name, c.class_name, r.room_number
        FROM timetable_entries te
        JOIN periods p ON te.period_id = p.id
        JOIN subjects s ON te.subject_id = s.id
        JOIN classes c ON te.class_id = c.id
        JOIN rooms r ON te.room_id = r.id
        WHERE te.teacher_id = ?
    ";
    
    $params = [$teacher_id];
    
    if ($day) {
        $sql .= " AND te.day_of_week = ?";
        $params[] = $day;
    }
    
    $sql .= " ORDER BY te.day_of_week, p.start_time";
    
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

function getClassSchedule($class_id, $day = null) {
    global $pdo;
    
    $sql = "
        SELECT te.*, p.period_name, p.start_time, p.end_time,
               s.subject_name, u.full_name as teacher_name, r.room_number
        FROM timetable_entries te
        JOIN periods p ON te.period_id = p.id
        JOIN subjects s ON te.subject_id = s.id
        JOIN teachers t ON te.teacher_id = t.id
        JOIN users u ON t.user_id = u.id
        JOIN rooms r ON te.room_id = r.id
        WHERE te.class_id = ?
    ";
    
    $params = [$class_id];
    
    if ($day) {
        $sql .= " AND te.day_of_week = ?";
        $params[] = $day;
    }
    
    $sql .= " ORDER BY te.day_of_week, p.start_time";
    
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}
?>
<?php
require_once '../includes/config.php';
require_once '../includes/auth.php';
redirectIfNotLoggedIn();
redirectIfNotTeacher();

// Get teacher information
$teacher_id = null;
$stmt = $pdo->prepare("SELECT * FROM teachers WHERE user_id = ?");
$stmt->execute([$_SESSION['user_id']]);
$teacher = $stmt->fetch(PDO::FETCH_ASSOC);

if ($teacher) {
    $teacher_id = $teacher['id'];
}

$days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday'];
$current_day = date('l');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Teacher Dashboard - Timetable System</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link href="../assets/css/style.css" rel="stylesheet">
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
        <div class="container">
            <a class="navbar-brand" href="../index.php">
                <i class="fas fa-chalkboard-teacher"></i> Kabulonga SS - Teacher Portal
            </a>
            <div class="navbar-nav ms-auto">
                <span class="navbar-text me-3">
                    Welcome, <?php echo $_SESSION['full_name']; ?>!
                </span>
                <a class="nav-link" href="view_schedule.php"><i class="fas fa-calendar-alt"></i> My Schedule</a>
                <a class="nav-link" href="profile.php"><i class="fas fa-user"></i> Profile</a>
                <a class="nav-link" href="../logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a>
            </div>
        </div>
    </nav>
    
    <div class="container mt-4">
        <div class="row">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header bg-success text-white">
                        <h4><i class="fas fa-tachometer-alt"></i> Teacher Dashboard</h4>
                    </div>
                    <div class="card-body">
                        <?php if ($teacher): ?>
                            <div class="row mb-4">
                                <div class="col-md-6">
                                    <div class="card bg-light">
                                        <div class="card-body">
                                            <h6>Teacher Information</h6>
                                            <p class="mb-1"><strong>Name:</strong> <?php echo $_SESSION['full_name']; ?></p>
                                            <p class="mb-1"><strong>Teacher Code:</strong> <?php echo $teacher['teacher_code']; ?></p>
                                            <p class="mb-1"><strong>Specialization:</strong> <?php echo $teacher['specialization']; ?></p>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="card bg-light">
                                        <div class="card-body">
                                            <h6>Today's Schedule</h6>
                                            <p class="mb-1"><strong>Day:</strong> <?php echo $current_day; ?></p>
                                            <?php
                                            $stmt = $pdo->prepare("
                                                SELECT COUNT(*) as count 
                                                FROM timetable_entries 
                                                WHERE teacher_id = ? AND day_of_week = ?
                                            ");
                                            $stmt->execute([$teacher_id, $current_day]);
                                            $today_count = $stmt->fetch(PDO::FETCH_ASSOC)['count'];
                                            ?>
                                            <p class="mb-1"><strong>Classes Today:</strong> <?php echo $today_count; ?></p>
                                            <a href="view_schedule.php?day=<?php echo $current_day; ?>" class="btn btn-sm btn-success">View Today's Schedule</a>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <!-- Today's Classes -->
                            <h5>Today's Teaching Schedule (<?php echo $current_day; ?>)</h5>
                            <div class="table-responsive">
                                <table class="table table-bordered">
                                    <thead class="table-dark">
                                        <tr>
                                            <th>Time</th>
                                            <th>Subject</th>
                                            <th>Class</th>
                                            <th>Room</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                        $periods = getPeriods($current_day);
                                        foreach ($periods as $period): 
                                            if (!in_array($period['period_name'], ['Break', 'Lunch'])):
                                                
                                                $stmt = $pdo->prepare("
                                                    SELECT te.*, s.subject_name, c.class_name, r.room_number
                                                    FROM timetable_entries te
                                                    JOIN subjects s ON te.subject_id = s.id
                                                    JOIN classes c ON te.class_id = c.id
                                                    JOIN rooms r ON te.room_id = r.id
                                                    WHERE te.period_id = ? AND te.day_of_week = ? AND te.teacher_id = ?
                                                ");
                                                $stmt->execute([$period['id'], $current_day, $teacher_id]);
                                                $schedule = $stmt->fetch(PDO::FETCH_ASSOC);
                                                
                                                if ($schedule):
                                        ?>
                                                    <tr>
                                                        <td>
                                                            <strong><?php echo $period['period_name']; ?></strong><br>
                                                            <small><?php echo substr($period['start_time'], 0, 5) . ' - ' . substr($period['end_time'], 0, 5); ?></small>
                                                        </td>
                                                        <td><?php echo $schedule['subject_name']; ?></td>
                                                        <td><?php echo $schedule['class_name']; ?></td>
                                                        <td><?php echo $schedule['room_number']; ?></td>
                                                    </tr>
                                        <?php 
                                                else:
                                        ?>
                                                    <tr>
                                                        <td>
                                                            <strong><?php echo $period['period_name']; ?></strong><br>
                                                            <small><?php echo substr($period['start_time'], 0, 5) . ' - ' . substr($period['end_time'], 0, 5); ?></small>
                                                        </td>
                                                        <td colspan="3" class="text-muted text-center">Free period</td>
                                                    </tr>
                                        <?php 
                                                endif;
                                            endif;
                                        endforeach; 
                                        ?>
                                    </tbody>
                                </table>
                            </div>
                        <?php else: ?>
                            <div class="alert alert-warning">
                                Teacher profile not found. Please contact administrator.
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            
            <div class="col-md-4">
                <!-- Quick Stats -->
                <div class="card mb-4">
                    <div class="card-header bg-info text-white">
                        <h6><i class="fas fa-chart-bar"></i> Teaching Statistics</h6>
                    </div>
                    <div class="card-body">
                        <?php if ($teacher): ?>
                            <?php
                            // Total classes per week
                            $stmt = $pdo->prepare("
                                SELECT COUNT(*) as total_classes 
                                FROM timetable_entries 
                                WHERE teacher_id = ?
                            ");
                            $stmt->execute([$teacher_id]);
                            $stats = $stmt->fetch(PDO::FETCH_ASSOC);
                            ?>
                            <div class="text-center mb-3">
                                <h3 class="text-primary"><?php echo $stats['total_classes']; ?></h3>
                                <p class="mb-0">Total Classes Per Week</p>
                            </div>
                            
                            <div class="d-grid gap-2">
                                <a href="view_schedule.php" class="btn btn-outline-primary btn-sm">
                                    <i class="fas fa-calendar-week"></i> Weekly Schedule
                                </a>
                                <a href="my_classes.php" class="btn btn-outline-success btn-sm">
                                    <i class="fas fa-users"></i> My Classes
                                </a>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>

                <!-- Weekly Overview -->
                <div class="card">
                    <div class="card-header bg-warning text-dark">
                        <h6><i class="fas fa-calendar-alt"></i> Weekly Overview</h6>
                    </div>
                    <div class="card-body">
                        <?php if ($teacher): ?>
                            <?php foreach ($days as $day): ?>
                                <?php
                                $stmt = $pdo->prepare("
                                    SELECT COUNT(*) as count 
                                    FROM timetable_entries 
                                    WHERE day_of_week = ? AND teacher_id = ?
                                ");
                                $stmt->execute([$day, $teacher_id]);
                                $count = $stmt->fetch(PDO::FETCH_ASSOC)['count'];
                                ?>
                                <div class="d-flex justify-content-between align-items-center mb-2">
                                    <span><?php echo $day; ?></span>
                                    <span class="badge bg-<?php echo $count > 0 ? 'success' : 'secondary'; ?>">
                                        <?php echo $count; ?> classes
                                    </span>
                                </div>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <footer class="bg-dark text-white mt-5 py-3">
        <div class="container text-center">
            <p class="mb-0">&copy; 2025 Kabulonga Secondary School. Teacher Portal</p>
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
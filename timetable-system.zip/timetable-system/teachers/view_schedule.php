<?php
require_once '../includes/config.php';
require_once '../includes/auth.php';
require_once '../includes/functions.php';
redirectIfNotLoggedIn();
redirectIfNotTeacher();

// Get teacher information
$teacher_id = null;
$stmt = $pdo->prepare("SELECT * FROM teachers WHERE user_id = ?");
$stmt->execute([$_SESSION['user_id']]);
$teacher = $stmt->fetch(PDO::FETCH_ASSOC);

if ($teacher) {
    $teacher_id = $teacher['id'];
}

$days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday'];
$selected_day = isset($_GET['day']) ? $_GET['day'] : 'Monday';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Teaching Schedule - Teacher Portal</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link href="../assets/css/style.css" rel="stylesheet">
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
        <div class="container">
            <a class="navbar-brand" href="../index.php">
                <i class="fas fa-chalkboard-teacher"></i> Kabulonga SS - Teacher Portal
            </a>
            <div class="navbar-nav ms-auto">
                <a class="nav-link" href="dashboard.php"><i class="fas fa-tachometer-alt"></i> Dashboard</a>
                <a class="nav-link" href="profile.php"><i class="fas fa-user"></i> Profile</a>
                <a class="nav-link" href="../logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a>
            </div>
        </div>
    </nav>
    
    <div class="container mt-4">
        <div class="card">
            <div class="card-header bg-success text-white">
                <h4><i class="fas fa-calendar-alt"></i> My Teaching Schedule</h4>
                <p class="mb-0">Teacher: <?php echo $_SESSION['full_name']; ?> | Code: <?php echo $teacher ? $teacher['teacher_code'] : 'N/A'; ?></p>
            </div>
            <div class="card-body">
                <?php if (!$teacher): ?>
                    <div class="alert alert-warning">
                        Teacher profile not found. Please contact administrator.
                    </div>
                <?php else: ?>
                    <!-- Day Selector -->
                    <div class="row mb-4">
                        <div class="col-md-8">
                            <div class="btn-group" role="group">
                                <?php foreach ($days as $day): ?>
                                    <a href="?day=<?php echo $day; ?>" 
                                       class="btn btn-<?php echo $selected_day == $day ? 'success' : 'outline-success'; ?>">
                                        <?php echo $day; ?>
                                    </a>
                                <?php endforeach; ?>
                            </div>
                        </div>
                        <div class="col-md-4 text-end">
                            <button class="btn btn-info print-timetable">
                                <i class="fas fa-print"></i> Print Schedule
                            </button>
                        </div>
                    </div>

                    <!-- Timetable -->
                    <div class="table-responsive">
                        <table class="table table-bordered table-hover">
                            <thead class="table-dark">
                                <tr>
                                    <th>Period</th>
                                    <th>Time</th>
                                    <th>Subject</th>
                                    <th>Class</th>
                                    <th>Room</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $periods = getPeriods($selected_day);
                                foreach ($periods as $period): 
                                    if (!in_array($period['period_name'], ['Break', 'Lunch'])):
                                        
                                        $stmt = $pdo->prepare("
                                            SELECT te.*, s.subject_name, c.class_name, r.room_number
                                            FROM timetable_entries te
                                            JOIN subjects s ON te.subject_id = s.id
                                            JOIN classes c ON te.class_id = c.id
                                            JOIN rooms r ON te.room_id = r.id
                                            WHERE te.period_id = ? AND te.day_of_week = ? AND te.teacher_id = ?
                                        ");
                                        $stmt->execute([$period['id'], $selected_day, $teacher_id]);
                                        $schedule = $stmt->fetch(PDO::FETCH_ASSOC);
                                        
                                        if ($schedule):
                                ?>
                                            <tr>
                                                <td><strong><?php echo $period['period_name']; ?></strong></td>
                                                <td><?php echo substr($period['start_time'], 0, 5) . ' - ' . substr($period['end_time'], 0, 5); ?></td>
                                                <td><?php echo $schedule['subject_name']; ?></td>
                                                <td><?php echo $schedule['class_name']; ?></td>
                                                <td><?php echo $schedule['room_number']; ?></td>
                                            </tr>
                                <?php 
                                        else:
                                ?>
                                            <tr>
                                                <td><strong><?php echo $period['period_name']; ?></strong></td>
                                                <td><?php echo substr($period['start_time'], 0, 5) . ' - ' . substr($period['end_time'], 0, 5); ?></td>
                                                <td colspan="3" class="text-muted text-center">Free period</td>
                                            </tr>
                                <?php 
                                        endif;
                                    endif;
                                endforeach; 
                                ?>
                            </tbody>
                        </table>
                    </div>

                    <!-- Weekly Summary -->
                    <div class="mt-4">
                        <h5>Weekly Teaching Summary</h5>
                        <div class="row">
                            <?php foreach ($days as $day): ?>
                                <div class="col-md-2 mb-3">
                                    <div class="card">
                                        <div class="card-body text-center">
                                            <h6><?php echo substr($day, 0, 3); ?></h6>
                                            <?php
                                            $stmt = $pdo->prepare("
                                                SELECT COUNT(*) as count 
                                                FROM timetable_entries 
                                                WHERE day_of_week = ? AND teacher_id = ?
                                            ");
                                            $stmt->execute([$day, $teacher_id]);
                                            $count = $stmt->fetch(PDO::FETCH_ASSOC)['count'];
                                            ?>
                                            <h3 class="text-<?php echo $count > 0 ? 'success' : 'secondary'; ?>">
                                                <?php echo $count; ?>
                                            </h3>
                                            <small>classes</small>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    </div>

                    <!-- Teaching Statistics -->
                    <div class="row mt-4">
                        <div class="col-md-6">
                            <div class="card bg-light">
                                <div class="card-body">
                                    <h6>Subjects You Teach</h6>
                                    <?php
                                    $stmt = $pdo->prepare("
                                        SELECT DISTINCT s.subject_name 
                                        FROM timetable_entries te
                                        JOIN subjects s ON te.subject_id = s.id
                                        WHERE te.teacher_id = ?
                                        ORDER BY s.subject_name
                                    ");
                                    $stmt->execute([$teacher_id]);
                                    $subjects = $stmt->fetchAll(PDO::FETCH_ASSOC);
                                    
                                    foreach ($subjects as $subject):
                                    ?>
                                        <span class="badge bg-primary me-1 mb-1"><?php echo $subject['subject_name']; ?></span>
                                    <?php endforeach; ?>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="card bg-light">
                                <div class="card-body">
                                    <h6>Classes You Teach</h6>
                                    <?php
                                    $stmt = $pdo->prepare("
                                        SELECT DISTINCT c.class_name 
                                        FROM timetable_entries te
                                        JOIN classes c ON te.class_id = c.id
                                        WHERE te.teacher_id = ?
                                        ORDER BY c.class_name
                                    ");
                                    $stmt->execute([$teacher_id]);
                                    $classes = $stmt->fetchAll(PDO::FETCH_ASSOC);
                                    
                                    foreach ($classes as $class):
                                    ?>
                                        <span class="badge bg-success me-1 mb-1"><?php echo $class['class_name']; ?></span>
                                    <?php endforeach; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <footer class="bg-dark text-white mt-5 py-3">
        <div class="container text-center">
            <p class="mb-0">&copy; 2025 Kabulonga Secondary School. Teacher Portal</p>
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="../assets/js/script.js"></script>
</body>
</html>
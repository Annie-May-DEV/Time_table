<?php
// Enable all error reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);

echo "<h1>Database Connection Test</h1>";

try {
    // Test database connection
    $pdo = new PDO("mysql:host=localhost;dbname=timetable_db", "root", "");
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    echo "<p style='color: green;'>✓ Database connection successful</p>";
    
    // Test users table
    $stmt = $pdo->query("SELECT COUNT(*) as count FROM users");
    $result = $stmt->fetch(PDO::FETCH_ASSOC);
    echo "<p>✓ Users table: " . $result['count'] . " users found</p>";
    
    // Test if admin user exists
    $stmt = $pdo->prepare("SELECT * FROM users WHERE username = 'admin'");
    $stmt->execute();
    $admin = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($admin) {
        echo "<p style='color: green;'>✓ Admin user found</p>";
        echo "<p>Username: " . $admin['username'] . "</p>";
        echo "<p>Role: " . $admin['role'] . "</p>";
        
        // Test password verification
        if (password_verify('password', $admin['password'])) {
            echo "<p style='color: green;'>✓ Admin password verification successful</p>";
        } else {
            echo "<p style='color: red;'>✗ Admin password verification failed</p>";
        }
    } else {
        echo "<p style='color: red;'>✗ Admin user not found</p>";
    }
    
    // Test teachers
    $stmt = $pdo->query("SELECT COUNT(*) as count FROM teachers");
    $result = $stmt->fetch(PDO::FETCH_ASSOC);
    echo "<p>✓ Teachers table: " . $result['count'] . " teachers found</p>";
    
    echo "<h2 style='color: green;'>All tests passed! Database is working correctly.</h2>";
    
} catch (PDOException $e) {
    echo "<p style='color: red;'>✗ Database error: " . $e->getMessage() . "</p>";
} catch (Exception $e) {
    echo "<p style='color: red;'>✗ General error: " . $e->getMessage() . "</p>";
}
?>

<a href="login.php" style="display: inline-block; margin-top: 20px; padding: 10px 20px; background: #007bff; color: white; text-decoration: none; border-radius: 5px;">Test Login Page</a>
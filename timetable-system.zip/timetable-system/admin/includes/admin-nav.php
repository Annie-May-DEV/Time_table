<nav class="navbar navbar-expand-lg navbar-dark bg-primary">
    <div class="container">
        <a class="navbar-brand" href="../index.php">
            Kabulonga SS - Admin Panel
        </a>
        <div class="navbar-nav ms-auto">
            <a class="nav-link" href="dashboard.php">Dashboard</a>
            <a class="nav-link" href="manage_teachers.php">Teachers</a>
            <a class="nav-link" href="manage_subjects.php">Subjects</a>
            <a class="nav-link" href="manage_classes.php">Classes</a>
            <a class="nav-link" href="manage_rooms.php">Rooms</a>
            <a class="nav-link" href="generate_timetable.php">Timetable</a>
            <a class="nav-link" href="../logout.php">Logout</a>
        </div>
    </div>
</nav>
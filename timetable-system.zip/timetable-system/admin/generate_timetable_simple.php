<?php
require_once '../includes/config.php';
require_once '../includes/auth.php';
redirectIfNotLoggedIn();
redirectIfNotAdmin();

// Simple helper functions for this page only
function getSubjectsSimple() {
    global $pdo;
    try {
        $stmt = $pdo->query("SELECT * FROM subjects ORDER BY subject_name");
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch (Exception $e) {
        return [];
    }
}

function getTeachersSimple() {
    global $pdo;
    try {
        $stmt = $pdo->query("SELECT t.*, u.full_name FROM teachers t JOIN users u ON t.user_id = u.id");
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch (Exception $e) {
        return [];
    }
}

function getClassesSimple() {
    global $pdo;
    try {
        $stmt = $pdo->query("SELECT * FROM classes ORDER BY class_level, class_name");
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch (Exception $e) {
        return [];
    }
}

function getRoomsSimple() {
    global $pdo;
    try {
        $stmt = $pdo->query("SELECT * FROM rooms ORDER BY room_number");
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch (Exception $e) {
        return [];
    }
}

function getPeriodsSimple($day = 'Monday') {
    global $pdo;
    try {
        $stmt = $pdo->prepare("SELECT * FROM periods WHERE day_of_week = ? ORDER BY start_time");
        $stmt->execute([$day]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch (Exception $e) {
        return [];
    }
}

$days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday'];
$success = $error = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['add_schedule'])) {
    $period_id = $_POST['period_id'];
    $subject_id = $_POST['subject_id'];
    $teacher_id = $_POST['teacher_id'];
    $class_id = $_POST['class_id'];
    $room_id = $_POST['room_id'];
    $day_of_week = $_POST['day_of_week'];
    
    try {
        $stmt = $pdo->prepare("INSERT INTO timetable_entries (period_id, subject_id, teacher_id, class_id, room_id, day_of_week) VALUES (?, ?, ?, ?, ?, ?)");
        $stmt->execute([$period_id, $subject_id, $teacher_id, $class_id, $room_id, $day_of_week]);
        $success = "Schedule added successfully!";
    } catch (Exception $e) {
        $error = "Error adding schedule: " . $e->getMessage();
    }
}

// Get data for forms
$subjects = getSubjectsSimple();
$teachers = getTeachersSimple();
$classes = getClassesSimple();
$rooms = getRoomsSimple();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Generate Timetable - Timetable System</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <?php include 'includes/admin-nav.php'; ?>
    
    <div class="container mt-4">
        <h2>Generate Timetable</h2>
        
        <?php if (isset($success)): ?>
            <div class="alert alert-success"><?php echo $success; ?></div>
        <?php endif; ?>
        
        <?php if (isset($error)): ?>
            <div class="alert alert-danger"><?php echo $error; ?></div>
        <?php endif; ?>
        
        <div class="card mb-4">
            <div class="card-header">
                <h5>Add Schedule Entry</h5>
            </div>
            <div class="card-body">
                <form method="POST">
                    <div class="row">
                        <div class="col-md-3">
                            <label class="form-label">Day of Week</label>
                            <select class="form-select" name="day_of_week" required>
                                <?php foreach ($days as $day): ?>
                                    <option value="<?php echo $day; ?>"><?php echo $day; ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-3">
                            <label class="form-label">Period</label>
                            <select class="form-select" name="period_id" required>
                                <option value="">Select Period</option>
                                <?php 
                                $periods = getPeriodsSimple('Monday');
                                foreach ($periods as $period): 
                                    if (!in_array($period['period_name'], ['Break', 'Lunch'])):
                                ?>
                                    <option value="<?php echo $period['id']; ?>">
                                        <?php echo $period['period_name'] . ' (' . substr($period['start_time'], 0, 5) . '-' . substr($period['end_time'], 0, 5) . ')'; ?>
                                    </option>
                                <?php 
                                    endif;
                                endforeach; 
                                ?>
                            </select>
                        </div>
                        <div class="col-md-3">
                            <label class="form-label">Subject</label>
                            <select class="form-select" name="subject_id" required>
                                <option value="">Select Subject</option>
                                <?php foreach ($subjects as $subject): ?>
                                    <option value="<?php echo $subject['id']; ?>"><?php echo $subject['subject_name']; ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-3">
                            <label class="form-label">Teacher</label>
                            <select class="form-select" name="teacher_id" required>
                                <option value="">Select Teacher</option>
                                <?php foreach ($teachers as $teacher): ?>
                                    <option value="<?php echo $teacher['id']; ?>"><?php echo $teacher['full_name']; ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>
                    <div class="row mt-3">
                        <div class="col-md-6">
                            <label class="form-label">Class</label>
                            <select class="form-select" name="class_id" required>
                                <option value="">Select Class</option>
                                <?php foreach ($classes as $class): ?>
                                    <option value="<?php echo $class['id']; ?>"><?php echo $class['class_name']; ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Room</label>
                            <select class="form-select" name="room_id" required>
                                <option value="">Select Room</option>
                                <?php foreach ($rooms as $room): ?>
                                    <option value="<?php echo $room['id']; ?>"><?php echo $room['room_number']; ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>
                    <div class="mt-3">
                        <button type="submit" name="add_schedule" class="btn btn-primary">Add to Timetable</button>
                    </div>
                </form>
            </div>
        </div>
        
        <div class="alert alert-info">
            <strong>Note:</strong> This is a simplified version. For full functionality, ensure all database tables are created.
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
<?php
require_once '../includes/config.php';
require_once '../includes/auth.php';
redirectIfNotLoggedIn();
redirectIfNotAdmin();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - Timetable System</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="../assets/css/style.css" rel="stylesheet">
</head>
<body>
    <?php include 'includes/admin-nav.php'; ?>
    
    <div class="container mt-4">
        <h2>Admin Dashboard</h2>
        <p class="lead">Manage your school's timetable and resources</p>
        
        <div class="row mt-4">






            <div class="col-md-3 mb-4">
                <div class="card text-white bg-primary">
                    <div class="card-body">
                        <h5 class="card-title">Teachers</h5>
                        <p class="card-text">Manage teaching staff</p>
                        <a href="manage_teachers.php" class="btn btn-light">Manage</a>
                    </div>
                </div>
            </div>
            <div class="col-md-3 mb-4">
                <div class="card text-white bg-success">
                    <div class="card-body">
                        <h5 class="card-title">Subjects</h5>
                        <p class="card-text">Manage course subjects</p>
                        <a href="manage_subjects.php" class="btn btn-light">Manage</a>
                    </div>
                </div>
            </div>
            <div class="col-md-3 mb-4">
                <div class="card text-white bg-warning">
                    <div class="card-body">
                        <h5 class="card-title">Classes</h5>
                        <p class="card-text">Manage class levels</p>
                        <a href="manage_classes.php" class="btn btn-light">Manage</a>
                    </div>
                </div>
            </div>
            <div class="col-md-3 mb-4">
                <div class="card text-white bg-info">
                    <div class="card-body">
                        <h5 class="card-title">Rooms</h5>
                        <p class="card-text">Manage classrooms</p>
                        <a href="manage_rooms.php" class="btn btn-light">Manage</a>
                    </div>
                </div>
            </div>




            <!-- Add this card to the existing row in admin/dashboard.php -->
<div class="col-md-3 mb-4">
    <div class="card text-white bg-warning">
        <div class="card-body">
            <h5 class="card-title">Students</h5>
            <p class="card-text">Manage student accounts</p>
            <a href="manage_students.php" class="btn btn-light">Manage</a>
        </div>
    </div>
</div>



        </div>
        
        <div class="row mt-4">
            <div class="col-md-6 mb-4">
                <div class="card text-white bg-dark">
                    <div class="card-body">
                        <h5 class="card-title">Generate Timetable</h5>
                        <p class="card-text">Create and manage schedules</p>
                        <a href="generate_timetable.php" class="btn btn-light">Generate</a>
                    </div>
                </div>
            </div>
            <div class="col-md-6 mb-4">
                <div class="card text-white bg-secondary">
                    <div class="card-body">
                        <h5 class="card-title">View Timetable</h5>
                        <p class="card-text">View complete schedule</p>
                        <a href="view_timetable.php" class="btn btn-light">View</a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
<?php
require_once '../includes/config.php';
require_once '../includes/auth.php';
require_once '../includes/functions.php';
redirectIfNotLoggedIn();
redirectIfNotAdmin();

$days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday'];
$selected_day = isset($_GET['day']) ? $_GET['day'] : 'Monday';
$selected_class = isset($_GET['class_id']) ? $_GET['class_id'] : 'all';

// Get classes for filter
$classes = getClasses();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Timetable - Timetable System</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="../assets/css/style.css" rel="stylesheet">
</head>
<body>
    <?php include 'includes/admin-nav.php'; ?>
    
    <div class="container mt-4">
        <h2>View Complete Timetable</h2>
        
        <!-- Filters -->
        <div class="card mb-4">
            <div class="card-body">
                <form method="GET" class="row g-3">
                    <div class="col-md-4">
                        <label class="form-label">Select Day</label>
                        <select class="form-select" name="day" onchange="this.form.submit()">
                            <?php foreach ($days as $day): ?>
                                <option value="<?php echo $day; ?>" <?php echo $selected_day == $day ? 'selected' : ''; ?>>
                                    <?php echo $day; ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="col-md-4">
                        <label class="form-label">Filter by Class</label>
                        <select class="form-select" name="class_id" onchange="this.form.submit()">
                            <option value="all" <?php echo $selected_class == 'all' ? 'selected' : ''; ?>>All Classes</option>
                            <?php foreach ($classes as $class): ?>
                                <option value="<?php echo $class['id']; ?>" <?php echo $selected_class == $class['id'] ? 'selected' : ''; ?>>
                                    <?php echo $class['class_name']; ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="col-md-4">
                        <label class="form-label">&nbsp;</label>
                        <div>
                            <a href="view_timetable.php" class="btn btn-secondary">Reset Filters</a>
                        </div>
                    </div>
                </form>
            </div>
        </div>

        <!-- Timetable -->
        <div class="card">
            <div class="card-header">
                <h5>Timetable for <?php echo $selected_day; ?></h5>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-bordered table-hover">
                        <thead class="table-dark">
                            <tr>
                                <th>Period</th>
                                <th>Time</th>
                                <th>Subject</th>
                                <th>Teacher</th>
                                <th>Class</th>
                                <th>Room</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $periods = getPeriods($selected_day);
                            foreach ($periods as $period): 
                                if (!in_array($period['period_name'], ['Break', 'Lunch'])):
                                    
                                    // Build query based on filters
                                    $sql = "
                                        SELECT te.*, s.subject_name, u.full_name as teacher_name, c.class_name, r.room_number
                                        FROM timetable_entries te
                                        JOIN subjects s ON te.subject_id = s.id
                                        JOIN teachers t ON te.teacher_id = t.id
                                        JOIN users u ON t.user_id = u.id
                                        JOIN classes c ON te.class_id = c.id
                                        JOIN rooms r ON te.room_id = r.id
                                        WHERE te.period_id = ? AND te.day_of_week = ?
                                    ";
                                    
                                    $params = [$period['id'], $selected_day];
                                    
                                    if ($selected_class != 'all') {
                                        $sql .= " AND te.class_id = ?";
                                        $params[] = $selected_class;
                                    }
                                    
                                    $sql .= " ORDER BY c.class_name";
                                    
                                    $stmt = $pdo->prepare($sql);
                                    $stmt->execute($params);
                                    $entries = $stmt->fetchAll(PDO::FETCH_ASSOC);
                                    
                                    if (count($entries) > 0):
                                        foreach ($entries as $entry):
                            ?>
                                            <tr>
                                                <td><strong><?php echo $period['period_name']; ?></strong></td>
                                                <td><?php echo substr($period['start_time'], 0, 5) . ' - ' . substr($period['end_time'], 0, 5); ?></td>
                                                <td><?php echo $entry['subject_name']; ?></td>
                                                <td><?php echo $entry['teacher_name']; ?></td>
                                                <td><?php echo $entry['class_name']; ?></td>
                                                <td><?php echo $entry['room_number']; ?></td>
                                                <td>
                                                    <form method="POST" action="generate_timetable.php" style="display: inline;">
                                                        <input type="hidden" name="entry_id" value="<?php echo $entry['id']; ?>">
                                                        <button type="submit" name="delete_entry" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure you want to delete this schedule entry?')">Delete</button>
                                                    </form>
                                                </td>
                                            </tr>
                            <?php 
                                        endforeach;
                                    else:
                            ?>
                                        <tr>
                                            <td><strong><?php echo $period['period_name']; ?></strong></td>
                                            <td><?php echo substr($period['start_time'], 0, 5) . ' - ' . substr($period['end_time'], 0, 5); ?></td>
                                            <td colspan="5" class="text-muted text-center">No schedule for this period</td>
                                        </tr>
                            <?php 
                                    endif;
                                endif;
                            endforeach; 
                            ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <!-- Weekly Overview -->
        <div class="card mt-4">
            <div class="card-header">
                <h5>Weekly Schedule Overview</h5>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-bordered">
                        <thead class="table-primary">
                            <tr>
                                <th>Time/Day</th>
                                <?php foreach ($days as $day): ?>
                                    <th><?php echo $day; ?></th>
                                <?php endforeach; ?>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $periods = getPeriods('Monday');
                            foreach ($periods as $period): 
                                if (!in_array($period['period_name'], ['Break', 'Lunch'])):
                            ?>
                                    <tr>
                                        <td>
                                            <strong><?php echo $period['period_name']; ?></strong><br>
                                            <small><?php echo substr($period['start_time'], 0, 5) . '-' . substr($period['end_time'], 0, 5); ?></small>
                                        </td>
                                        <?php foreach ($days as $day): ?>
                                            <td>
                                                <?php
                                                $stmt = $pdo->prepare("
                                                    SELECT COUNT(*) as count 
                                                    FROM timetable_entries 
                                                    WHERE period_id = ? AND day_of_week = ?
                                                ");
                                                $stmt->execute([$period['id'], $day]);
                                                $count = $stmt->fetch(PDO::FETCH_ASSOC)['count'];
                                                ?>
                                                <span class="badge bg-<?php echo $count > 0 ? 'success' : 'secondary'; ?>">
                                                    <?php echo $count; ?> scheduled
                                                </span>
                                            </td>
                                        <?php endforeach; ?>
                                    </tr>
                            <?php 
                                endif;
                            endforeach; 
                            ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
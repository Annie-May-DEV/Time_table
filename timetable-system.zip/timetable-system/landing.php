<?php
require_once 'includes/config.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kabulonga Secondary School - Timetable System</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link href="assets/css/style.css" rel="stylesheet">
    <style>
        .landing-hero {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 100px 0;
            text-align: center;
        }
        .feature-card {
            transition: transform 0.3s ease;
            border: none;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
        }
        .feature-card:hover {
            transform: translateY(-10px);
        }
        .btn-landing {
            padding: 15px 30px;
            font-size: 1.2rem;
            border-radius: 50px;
            margin: 10px;
            transition: all 0.3s ease;
        }
        .school-info {
            background-color: #f8f9fa;
            padding: 60px 0;
        }
    </style>
</head>
<body>
    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container">
            <a class="navbar-brand" href="landing.php">
                <i class="fas fa-school"></i> Kabulonga Secondary School
            </a>
        </div>
    </nav>

    <!-- Hero Section -->
    <section class="landing-hero">
        <div class="container">
            <div class="row">
                <div class="col-md-8 mx-auto">
                    <h1 class="display-4 mb-4">School Timetable Management System</h1>
                    <p class="lead mb-5">Streamlining class scheduling and timetable access for Kabulonga Secondary School community</p>
                    
                    <!-- Main Action Buttons -->
                    <div class="row justify-content-center">
                        <!-- In the hero section of landing.php, update the button -->
<div class="col-md-5">
    <a href="public_timetable.php" class="btn btn-light btn-landing w-100">
        <i class="fas fa-calendar-alt fa-2x mb-2"></i><br>
        View Timetable
        <small class="d-block mt-1">Check class schedules</small>
    </a>
</div>
                        <div class="col-md-5">
                            <a href="login.php" class="btn btn-outline-light btn-landing w-100">
                                <i class="fas fa-sign-in-alt fa-2x mb-2"></i><br>
                                Login
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Features Section -->
    <section class="py-5">
        <div class="container">
            <div class="row">
                <div class="col-md-4 mb-4">
                    <div class="card feature-card h-100 text-center">
                        <div class="card-body">
                            <i class="fas fa-eye fa-3x text-primary mb-3"></i>
                            <h5 class="card-title">View Timetable</h5>
                            <p class="card-text">Access the school timetable without logging in. Perfect for students and parents to check daily schedules.</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 mb-4">
                    <div class="card feature-card h-100 text-center">
                        <div class="card-body">
                            <i class="fas fa-chalkboard-teacher fa-3x text-success mb-3"></i>
                            <h5 class="card-title">Teacher Login</h5>
                            <p class="card-text">Teachers can access their personalized schedules, teaching assignments, and class information.</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 mb-4">
                    <div class="card feature-card h-100 text-center">
                        <div class="card-body">
                            <i class="fas fa-user-shield fa-3x text-warning mb-3"></i>
                            <h5 class="card-title">Admin Login</h5>
                            <p class="card-text">Administrators can manage the complete timetable system, teachers, classes, and generate schedules.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- School Information -->
    <section class="school-info">
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <h3>About Kabulonga Secondary School</h3>
                    <p class="lead">Providing quality education since 1965, Kabulonga Secondary School is committed to academic excellence and student development.</p>
                    <ul class="list-unstyled">
                        <li><i class="fas fa-check text-success"></i> Well-equipped classrooms and laboratories</li>
                        <li><i class="fas fa-check text-success"></i> Qualified and experienced teaching staff</li>
                        <li><i class="fas fa-check text-success"></i> Comprehensive curriculum</li>
                        <li><i class="fas fa-check text-success"></i> Modern timetable management system</li>
                    </ul>
                </div>
                <div class="col-md-6">
                    <h3>System Features</h3>
                    <div class="row">
                        <div class="col-6">
                            <div class="card bg-light mb-3">
                                <div class="card-body text-center">
                                    <i class="fas fa-bolt fa-2x text-primary"></i>
                                    <h6>Fast Access</h6>
                                </div>
                            </div>
                        </div>
                        <div class="col-6">
                            <div class="card bg-light mb-3">
                                <div class="card-body text-center">
                                    <i class="fas fa-mobile-alt fa-2x text-success"></i>
                                    <h6>Mobile Friendly</h6>
                                </div>
                            </div>
                        </div>
                        <div class="col-6">
                            <div class="card bg-light mb-3">
                                <div class="card-body text-center">
                                    <i class="fas fa-sync fa-2x text-info"></i>
                                    <h6>Real-time Updates</h6>
                                </div>
                            </div>
                        </div>
                        <div class="col-6">
                            <div class="card bg-light mb-3">
                                <div class="card-body text-center">
                                    <i class="fas fa-shield-alt fa-2x text-warning"></i>
                                    <h6>Secure</h6>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Footer -->
    <footer class="bg-dark text-white py-4">
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <h5>Kabulonga Secondary School</h5>
                    <p>Providing quality education with modern technology solutions.</p>
                </div>
                <div class="col-md-6 text-end">
                    <p>&copy; 2025 Kabulonga Secondary School<br>
                    Developed by Gladys Katongo</p>
                </div>
            </div>
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
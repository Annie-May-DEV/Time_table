<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

echo "<h2>Session Test</h2>";

// Test session functionality
$_SESSION['test'] = 'Session is working!';

if (isset($_SESSION['test'])) {
    echo "<p style='color: green;'>✓ Session test passed: " . $_SESSION['test'] . "</p>";
} else {
    echo "<p style='color: red;'>✗ Session test failed</p>";
}

// Show all session data
echo "<h3>Current Session Data:</h3>";
echo "<pre>";
print_r($_SESSION);
echo "</pre>";

// Clear test data
unset($_SESSION['test']);
?>

<a href="login.php" style="display: inline-block; margin-top: 20px; padding: 10px 20px; background: #007bff; color: white; text-decoration: none; border-radius: 5px;">Test Login Page</a>
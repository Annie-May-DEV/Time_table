<?php
require_once 'includes/config.php';

echo "<h2>Database Tables Check</h2>";

$tables = [
    'users',
    'teachers', 
    'students',
    'subjects',
    'classes',
    'rooms',
    'periods',
    'timetable_entries'
];

$all_tables_exist = true;

foreach ($tables as $table) {
    try {
        $stmt = $pdo->query("SELECT 1 FROM $table LIMIT 1");
        echo "<p style='color: green;'>✓ Table '$table' exists</p>";
    } catch (PDOException $e) {
        echo "<p style='color: red;'>✗ Table '$table' is missing</p>";
        $all_tables_exist = false;
    }
}

if ($all_tables_exist) {
    echo "<h3 style='color: green;'>All tables are present! System is ready.</h3>";
    
    // Count records in each table
    echo "<h4>Record Counts:</h4>";
    foreach ($tables as $table) {
        $stmt = $pdo->query("SELECT COUNT(*) as count FROM $table");
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        echo "<p>$table: " . $result['count'] . " records</p>";
    }
    
    echo "<a href='admin/generate_timetable.php' style='display: inline-block; padding: 10px 20px; background: #007bff; color: white; text-decoration: none; border-radius: 5px;'>Go to Generate Timetable</a>";
} else {
    echo "<h3 style='color: red;'>Some tables are missing. Please run the complete database setup.</h3>";
    echo "<p>Run the SQL file: <code>database/complete_setup.sql</code> in phpMyAdmin</p>";
}
?>
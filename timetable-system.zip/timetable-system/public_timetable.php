<?php
require_once 'includes/config.php';

// Get all classes for the filter dropdown
function getClassesForPublic() {
    global $pdo;
    try {
        $stmt = $pdo->query("SELECT * FROM classes ORDER BY class_level, class_name");
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch (Exception $e) {
        return [];
    }
}

// Get timetable data for a specific class and day
function getTimetableForClass($class_id = null, $day = 'Monday') {
    global $pdo;
    
    try {
        $sql = "
            SELECT 
                te.*,
                p.period_name,
                p.start_time,
                p.end_time,
                s.subject_name,
                s.subject_code,
                u.full_name as teacher_name,
                c.class_name,
                r.room_number,
                r.room_type
            FROM timetable_entries te
            JOIN periods p ON te.period_id = p.id
            JOIN subjects s ON te.subject_id = s.id
            JOIN teachers t ON te.teacher_id = t.id
            JOIN users u ON t.user_id = u.id
            JOIN classes c ON te.class_id = c.id
            JOIN rooms r ON te.room_id = r.id
            WHERE te.day_of_week = ?
        ";
        
        $params = [$day];
        
        if ($class_id && $class_id !== 'all') {
            $sql .= " AND te.class_id = ?";
            $params[] = $class_id;
        }
        
        $sql .= " ORDER BY p.start_time, c.class_name";
        
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch (Exception $e) {
        return [];
    }
}

// Get days with available timetable data
function getDaysWithTimetable() {
    global $pdo;
    try {
        $stmt = $pdo->query("
            SELECT DISTINCT day_of_week 
            FROM timetable_entries 
            ORDER BY FIELD(day_of_week, 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday')
        ");
        return $stmt->fetchAll(PDO::FETCH_COLUMN, 0);
    } catch (Exception $e) {
        return ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday'];
    }
}

$days = getDaysWithTimetable();
$classes = getClassesForPublic();

// Get current selections from URL parameters
$selected_day = isset($_GET['day']) ? $_GET['day'] : (count($days) > 0 ? $days[0] : 'Monday');
$selected_class = isset($_GET['class_id']) ? $_GET['class_id'] : 'all';

// Get timetable data
$timetable_data = getTimetableForClass($selected_class, $selected_day);

// Group timetable data by period for display
$periods_data = [];
foreach ($timetable_data as $entry) {
    $periods_data[$entry['period_id']][] = $entry;
}

// Get all periods for the selected day
$periods = [];
try {
    $stmt = $pdo->prepare("SELECT * FROM periods WHERE day_of_week = ? ORDER BY start_time");
    $stmt->execute([$selected_day]);
    $periods = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (Exception $e) {
    $periods = [];
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Public Timetable - Kabulonga Secondary School</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link href="assets/css/style.css" rel="stylesheet">
    <style>
        .public-header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 40px 0;
        }
        .timetable-card {
            border: none;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
            margin-bottom: 20px;
        }
        .period-card {
            border-left: 4px solid #007bff;
            margin-bottom: 10px;
        }
        .break-period {
            border-left-color: #28a745;
            background-color: #f8fff9;
        }
        .lunch-period {
            border-left-color: #ffc107;
            background-color: #fffbf0;
        }
        .subject-badge {
            font-size: 0.8rem;
            margin-right: 5px;
        }
        .timetable-cell {
            min-height: 80px;
        }
        .class-filter {
            background: #f8f9fa;
            border-radius: 10px;
            padding: 20px;
            margin-bottom: 20px;
        }
        .no-classes {
            text-align: center;
            padding: 40px;
            color: #6c757d;
        }
        .timetable-entry {
            border-radius: 8px;
            padding: 12px;
            margin-bottom: 8px;
            background: white;
            border: 1px solid #e9ecef;
            transition: transform 0.2s;
        }
        .timetable-entry:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
        }
    </style>
</head>
<body>
    <!-- Header -->
    <header class="public-header">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-md-8">
                    <h1><i class="fas fa-calendar-alt"></i> School Timetable</h1>
                    <p class="lead mb-0">Kabulonga Secondary School - Public Timetable Access</p>
                </div>
                <div class="col-md-4 text-end">
                    <a href="landing.php" class="btn btn-light me-2">
                        <i class="fas fa-home"></i> Home
                    </a>
                    <a href="login.php" class="btn btn-outline-light">
                        <i class="fas fa-sign-in-alt"></i> Staff Login
                    </a>
                </div>
            </div>
        </div>
    </header>

    <div class="container mt-4">
        <!-- Class Selection Filter -->
        <div class="class-filter">
            <div class="row g-3">
                <div class="col-md-4">
                    <label class="form-label fw-bold">Select Grade/Class</label>
                    <select class="form-select" id="classSelect" onchange="updateTimetable()">
                        <option value="all" <?php echo $selected_class == 'all' ? 'selected' : ''; ?>>All Classes</option>
                        <?php foreach ($classes as $class): ?>
                            <option value="<?php echo $class['id']; ?>" <?php echo $selected_class == $class['id'] ? 'selected' : ''; ?>>
                                <?php echo $class['class_name']; ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-md-4">
                    <label class="form-label fw-bold">Select Day</label>
                    <select class="form-select" id="daySelect" onchange="updateTimetable()">
                        <?php foreach ($days as $day): ?>
                            <option value="<?php echo $day; ?>" <?php echo $selected_day == $day ? 'selected' : ''; ?>>
                                <?php echo $day; ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-md-4">
                    <label class="form-label fw-bold">&nbsp;</label>
                    <div class="d-grid">
                        <button class="btn btn-success print-timetable" onclick="window.print()">
                            <i class="fas fa-print"></i> Print Timetable
                        </button>
                    </div>
                </div>
            </div>
        </div>

        <!-- Timetable Display -->
        <div class="card timetable-card">
            <div class="card-header bg-primary text-white">
                <div class="row align-items-center">
                    <div class="col-md-8">
                        <h4 class="mb-0">
                            <i class="fas fa-calendar-week"></i> 
                            <?php 
                            if ($selected_class == 'all') {
                                echo "All Classes Timetable";
                            } else {
                                $selected_class_name = 'All Classes';
                                foreach ($classes as $class) {
                                    if ($class['id'] == $selected_class) {
                                        $selected_class_name = $class['class_name'];
                                        break;
                                    }
                                }
                                echo $selected_class_name . " Timetable";
                            }
                            ?>
                            - <?php echo $selected_day; ?>
                        </h4>
                    </div>
                    <div class="col-md-4 text-end">
                        <span class="badge bg-light text-dark">
                            <i class="fas fa-clock"></i> 
                            <?php echo count($timetable_data); ?> scheduled classes
                        </span>
                    </div>
                </div>
            </div>
            <div class="card-body">
                <?php if (count($timetable_data) > 0): ?>
                    <div class="table-responsive">
                        <table class="table table-bordered table-hover">
                            <thead class="table-dark">
                                <tr>
                                    <th width="15%">Time</th>
                                    <th width="15%">Period</th>
                                    <th width="20%">Subject</th>
                                    <th width="20%">Teacher</th>
                                    <th width="15%">Class</th>
                                    <th width="15%">Room</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($periods as $period): ?>
                                    <?php
                                    $period_entries = isset($periods_data[$period['id']]) ? $periods_data[$period['id']] : [];
                                    $is_break = in_array($period['period_name'], ['Break', 'Lunch']);
                                    $row_class = $is_break ? 'table-warning' : '';
                                    ?>
                                    
                                    <tr class="<?php echo $row_class; ?>">
                                        <td>
                                            <strong><?php echo substr($period['start_time'], 0, 5) . ' - ' . substr($period['end_time'], 0, 5); ?></strong>
                                        </td>
                                        <td>
                                            <span class="badge bg-<?php echo $is_break ? 'warning text-dark' : 'primary'; ?>">
                                                <?php echo $period['period_name']; ?>
                                            </span>
                                        </td>
                                        
                                        <?php if (count($period_entries) > 0): ?>
                                            <?php 
                                            // For periods with multiple classes, show the first one in main row
                                            $first_entry = $period_entries[0]; 
                                            ?>
                                            <td>
                                                <strong><?php echo $first_entry['subject_name']; ?></strong>
                                                <br>
                                                <small class="text-muted"><?php echo $first_entry['subject_code']; ?></small>
                                            </td>
                                            <td><?php echo $first_entry['teacher_name']; ?></td>
                                            <td>
                                                <span class="badge bg-success"><?php echo $first_entry['class_name']; ?></span>
                                            </td>
                                            <td>
                                                <span class="badge bg-info"><?php echo $first_entry['room_number']; ?></span>
                                                <br>
                                                <small class="text-muted"><?php echo $first_entry['room_type']; ?></small>
                                            </td>
                                        <?php else: ?>
                                            <td colspan="4" class="text-center text-muted">
                                                <?php if ($is_break): ?>
                                                    <i class="fas fa-coffee"></i> <?php echo $period['period_name']; ?> Time
                                                <?php else: ?>
                                                    No classes scheduled
                                                <?php endif; ?>
                                            </td>
                                        <?php endif; ?>
                                    </tr>
                                    
                                    <!-- Additional rows for multiple classes in same period -->
                                    <?php if (count($period_entries) > 1): ?>
                                        <?php for ($i = 1; $i < count($period_entries); $i++): ?>
                                            <?php $entry = $period_entries[$i]; ?>
                                            <tr class="bg-light">
                                                <td colspan="2" class="text-muted text-center">
                                                    <small>Also during this period:</small>
                                                </td>
                                                <td>
                                                    <small>
                                                        <strong><?php echo $entry['subject_name']; ?></strong>
                                                        <br>
                                                        <span class="text-muted"><?php echo $entry['subject_code']; ?></span>
                                                    </small>
                                                </td>
                                                <td><small><?php echo $entry['teacher_name']; ?></small></td>
                                                <td>
                                                    <small>
                                                        <span class="badge bg-secondary"><?php echo $entry['class_name']; ?></span>
                                                    </small>
                                                </td>
                                                <td>
                                                    <small>
                                                        <span class="badge bg-light text-dark"><?php echo $entry['room_number']; ?></span>
                                                    <br>
                                                        <span class="text-muted"><?php echo $entry['room_type']; ?></span>
                                                    </small>
                                                </td>
                                            </tr>
                                        <?php endfor; ?>
                                    <?php endif; ?>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php else: ?>
                    <div class="no-classes">
                        <i class="fas fa-calendar-times fa-3x mb-3"></i>
                        <h4>No Timetable Found</h4>
                        <p>No classes have been scheduled for <?php echo $selected_day; ?> 
                        <?php if ($selected_class != 'all'): ?>
                            for the selected class
                        <?php endif; ?>.</p>
                        <p class="text-muted">Please check back later or contact the school administration.</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>

        <!-- Quick Class Overview -->
        <?php if ($selected_class == 'all' && count($timetable_data) > 0): ?>
            <div class="card timetable-card">
                <div class="card-header bg-info text-white">
                    <h5 class="mb-0"><i class="fas fa-chart-bar"></i> Daily Class Overview</h5>
                </div>
                <div class="card-body">
                    <div class="row">
                        <?php
                        // Count classes per grade
                        $class_counts = [];
                        foreach ($timetable_data as $entry) {
                            $class_name = $entry['class_name'];
                            if (!isset($class_counts[$class_name])) {
                                $class_counts[$class_name] = 0;
                            }
                            $class_counts[$class_name]++;
                        }
                        ?>
                        <?php foreach ($class_counts as $class_name => $count): ?>
                            <div class="col-md-3 col-6 mb-3">
                                <div class="card text-center">
                                    <div class="card-body">
                                        <h6 class="card-title"><?php echo $class_name; ?></h6>
                                        <h3 class="text-primary"><?php echo $count; ?></h3>
                                        <small class="text-muted">classes today</small>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>
        <?php endif; ?>

        <!-- Information Card -->
        <div class="card timetable-card">
            <div class="card-body">
                <div class="row">
                    <div class="col-md-6">
                        <h6><i class="fas fa-info-circle text-primary"></i> About This Timetable</h6>
                        <p class="small mb-0">
                            This timetable shows all scheduled classes for <?php echo $selected_day; ?>. 
                            You can filter by specific grade/class using the dropdown above.
                        </p>
                    </div>
                    <div class="col-md-6">
                        <h6><i class="fas fa-sync-alt text-success"></i> Timetable Updates</h6>
                        <p class="small mb-0">
                            The timetable is updated regularly. For the most current information, 
                            please check back frequently or contact the school office.
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Footer -->
    <footer class="bg-dark text-white mt-5 py-4">
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <h5>Kabulonga Secondary School</h5>
                    <p class="mb-0">Accessing school timetable information made easy.</p>
                </div>
                <div class="col-md-6 text-end">
                    <a href="landing.php" class="btn btn-outline-light btn-sm">
                        <i class="fas fa-home"></i> Back to Home
                    </a>
                    <a href="login.php" class="btn btn-light btn-sm ms-2">
                        <i class="fas fa-sign-in-alt"></i> Staff Login
                    </a>
                </div>
            </div>
            <div class="row mt-3">
                <div class="col-12 text-center">
                    <p class="mb-0 small">
                        &copy; 2025 Kabulonga Secondary School. 
                        Timetable System v2.0
                    </p>
                </div>
            </div>
        </div>
    </footer>

    <script>
        function updateTimetable() {
            const classId = document.getElementById('classSelect').value;
            const day = document.getElementById('daySelect').value;
            const url = new URL(window.location.href);
            
            url.searchParams.set('class_id', classId);
            url.searchParams.set('day', day);
            
            window.location.href = url.toString();
        }

        // Auto-refresh every 5 minutes to check for updates
        setInterval(() => {
            // Only refresh if user is not interacting with the page
            if (!document.hidden) {
                const currentUrl = new URL(window.location.href);
                window.location.href = currentUrl.toString();
            }
        }, 300000); // 5 minutes

        // Add loading indicator when filtering
        document.getElementById('classSelect').addEventListener('change', function() {
            showLoading();
        });

        document.getElementById('daySelect').addEventListener('change', function() {
            showLoading();
        });

        function showLoading() {
            const cardBody = document.querySelector('.card-body');
            if (cardBody) {
                cardBody.innerHTML = `
                    <div class="text-center py-4">
                        <div class="spinner-border text-primary" role="status">
                            <span class="visually-hidden">Loading...</span>
                        </div>
                        <p class="mt-2">Loading timetable data...</p>
                    </div>
                `;
            }
        }
    </script>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
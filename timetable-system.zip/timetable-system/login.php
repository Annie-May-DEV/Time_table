<?php
// Start session at the very beginning
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Include config after session start
require_once 'includes/config.php';

// Simple login function
function authenticateUser($username, $password, $role) {
    global $pdo;
    
    try {
        $stmt = $pdo->prepare("SELECT * FROM users WHERE username = ? AND role = ?");
        $stmt->execute([$username, $role]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($user && password_verify($password, $user['password'])) {
            return $user;
        }
        return false;
    } catch (Exception $e) {
        error_log("Login error: " . $e->getMessage());
        return false;
    }
}

// Handle form submission
$error = '';
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['username'])) {
    $username = trim($_POST['username']);
    $password = trim($_POST['password']);
    $role = trim($_POST['role']);
    
    $user = authenticateUser($username, $password, $role);
    
    if ($user) {
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['username'] = $user['username'];
        $_SESSION['role'] = $user['role'];
        $_SESSION['full_name'] = $user['full_name'];
        
        // Redirect based on role
        switch ($user['role']) {
            case 'admin':
                header("Location: admin/dashboard.php");
                exit();
            case 'teacher':
                header("Location: teachers/dashboard.php");
                exit();
            case 'student':
                header("Location: students/dashboard.php");
                exit();
            default:
                header("Location: landing.php");
                exit();
        }
    } else {
        $error = "Invalid credentials for selected role!";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Staff Login - Kabulonga Secondary School</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        body {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            padding: 20px 0;
        }
        .login-card {
            border: none;
            border-radius: 15px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.2);
        }
        .role-btn {
            padding: 15px;
            border: 2px solid #dee2e6;
            border-radius: 10px;
            text-align: center;
            cursor: pointer;
            transition: all 0.3s ease;
            background: white;
            margin-bottom: 10px;
        }
        .role-btn:hover {
            border-color: #007bff;
            transform: translateY(-2px);
        }
        .role-btn.active {
            border-color: #007bff;
            background-color: #007bff;
            color: white;
        }
        .demo-accounts {
            font-size: 0.85rem;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-6 col-lg-5">
                <div class="card login-card">
                    <div class="card-body p-4">
                        <!-- Header -->
                        <div class="text-center mb-4">
                            <h2 class="text-primary mb-2">
                                <i class="fas fa-lock"></i> Staff Login
                            </h2>
                            <p class="text-muted mb-0">Select your role and enter your credentials</p>
                        </div>

                        <!-- Error Message -->
                        <?php if ($error): ?>
                            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                                <?php echo $error; ?>
                                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                            </div>
                        <?php endif; ?>

                        <!-- Login Form -->
                        <form method="POST" action="">
                            <!-- Role Selection -->
                            <div class="mb-4">
                                <label class="form-label mb-2"><strong>Select Login Type:</strong></label>
                                <div class="row g-2">
                                    <div class="col-6">
                                        <div class="role-btn active" onclick="selectRole('admin')" id="adminBtn">
                                            <i class="fas fa-user-shield fa-2x mb-2"></i>
                                            <div>Admin Login</div>
                                        </div>
                                    </div>
                                    <div class="col-6">
                                        <div class="role-btn" onclick="selectRole('teacher')" id="teacherBtn">
                                            <i class="fas fa-chalkboard-teacher fa-2x mb-2"></i>
                                            <div>Teacher Login</div>
                                        </div>
                                    </div>
                                </div>
                                <input type="hidden" name="role" id="selectedRole" value="admin" required>
                            </div>

                            <!-- Username -->
                            <div class="mb-3">
                                <label for="username" class="form-label">Username</label>
                                <div class="input-group">
                                    <span class="input-group-text bg-light"><i class="fas fa-user text-muted"></i></span>
                                    <input type="text" class="form-control" id="username" name="username" placeholder="Enter admin username" required>
                                </div>
                            </div>
                            
                            <!-- Password -->
                            <div class="mb-4">
                                <label for="password" class="form-label">Password</label>
                                <div class="input-group">
                                    <span class="input-group-text bg-light"><i class="fas fa-lock text-muted"></i></span>
                                    <input type="password" class="form-control" id="password" name="password" placeholder="Enter your password" required>
                                </div>
                            </div>
                            
                            <!-- Submit Button -->
                            <div class="d-grid">
                                <button type="submit" class="btn btn-primary btn-lg py-2">
                                    <i class="fas fa-sign-in-alt me-2"></i> Login
                                </button>
                            </div>
                        </form>

                        <!-- Demo Accounts -->
                        <div class="mt-4">
                            <div class="card border-0 bg-light">
                                <div class="card-body py-3">
                                    <h6 class="card-title mb-2"><i class="fas fa-key me-2"></i>Demo Accounts</h6>
                                    <div class="row demo-accounts">
                                        <div class="col-md-6 mb-2">
                                            <div class="border rounded p-2 bg-white">
                                                <strong class="d-block">Admin Account</strong>
                                                <small>User: <code>admin</code></small><br>
                                                <small>Pass: <code>password</code></small>
                                            </div>
                                        </div>
                                        <div class="col-md-6 mb-2">
                                            <div class="border rounded p-2 bg-white">
                                                <strong class="d-block">Teacher Account</strong>
                                                <small>User: <code>teacher1</code></small><br>
                                                <small>Pass: <code>password</code></small>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Navigation Links -->
                        <div class="text-center mt-4 pt-3 border-top">
                            <a href="landing.php" class="text-decoration-none me-3">
                                <i class="fas fa-home me-1"></i> Home
                            </a>
                            <a href="public_timetable.php" class="text-decoration-none">
                                <i class="fas fa-calendar-alt me-1"></i> View Timetable
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        function selectRole(role) {
            document.getElementById('selectedRole').value = role;
            
            // Update button styles
            document.querySelectorAll('.role-btn').forEach(btn => {
                btn.classList.remove('active');
            });
            
            document.getElementById(role + 'Btn').classList.add('active');
            
            // Update form placeholder based on role
            const usernameInput = document.getElementById('username');
            if (role === 'admin') {
                usernameInput.placeholder = "Enter admin username";
            } else if (role === 'teacher') {
                usernameInput.placeholder = "Enter teacher username";
            }
        }

        // Add some interactivity
        document.addEventListener('DOMContentLoaded', function() {
            // Focus on username field
            document.getElementById('username').focus();
            
            // Enter key submits form
            document.getElementById('password').addEventListener('keypress', function(e) {
                if (e.key === 'Enter') {
                    document.querySelector('form').submit();
                }
            });
        });
    </script>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>